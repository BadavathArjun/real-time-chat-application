document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const chatMessages = document.getElementById('chat-messages');
    const messageInput = document.getElementById('message-input');
    const sendButton = document.getElementById('send-button');
    const usernameInput = document.getElementById('username-input');
    const usernameSubmit = document.getElementById('username-submit');
    const usernameContainer = document.getElementById('username-container');
    const messageInputContainer = document.getElementById('message-input-container');
    const typingIndicator = document.getElementById('typing-indicator');
    const userList = document.getElementById('user-list');
    const userCount = document.getElementById('user-count');
    const usernameDisplay = document.getElementById('username-display');
    const userAvatar = document.getElementById('user-avatar');
    const connectionStatus = document.querySelector('.status-indicator');
    const connectionText = document.getElementById('connection-text');

    // Connect to Socket.io with advanced options
    const socket = io({
        reconnection: true,
        reconnectionDelay: 1000,
        reconnectionDelayMax: 5000,
        reconnectionAttempts: Infinity,
        timeout: 20000,
        transports: ['websocket']
    });

    // State variables
    let username = '';
    let isTyping = false;
    let typingTimeout;
    let isConnected = false;
    let activeUsers = [];

    // Initialize the application
    function init() {
        setupEventListeners();
        setupSocketEvents();
    }

    // Set up DOM event listeners
    function setupEventListeners() {
        // Username submission
        usernameSubmit.addEventListener('click', setUsername);
        usernameInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                setUsername();
            }
        });

        // Message submission
        sendButton.addEventListener('click', sendMessage);
        messageInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                sendMessage();
            }
        });

        // Typing indicators
        messageInput.addEventListener('input', handleTyping);
    }

    // Set up Socket.io event listeners
    function setupSocketEvents() {
        // Connection status
        socket.on('connect', () => {
            console.log('Connected to server');
            isConnected = true;
            updateConnectionStatus(true);
            if (username) {
                // Rejoin the chat if we were disconnected
                socket.emit('user-joined', username);
            }
        });

        socket.on('disconnect', (reason) => {
            console.log('Disconnected from server:', reason);
            isConnected = false;
            updateConnectionStatus(false);
            if (reason === 'io server disconnect') {
                // The disconnection was initiated by the server, need to reconnect manually
                setTimeout(() => {
                    socket.connect();
                }, 1000);
            }
        });

        socket.on('reconnect', (attempt) => {
            console.log('Reconnected to server after', attempt, 'attempts');
            updateConnectionStatus(true);
            if (username) {
                socket.emit('user-joined', username);
            }
        });

        socket.on('reconnect_attempt', (attempt) => {
            console.log('Reconnection attempt', attempt);
        });

        socket.on('reconnect_error', (error) => {
            console.log('Reconnection error:', error);
        });

        socket.on('reconnect_failed', () => {
            console.log('Reconnection failed');
            updateConnectionStatus(false);
        });

        // Chat events
        socket.on('chat-message', (data) => {
            if (!data || !data.username || !data.message) return;
            const isSentByMe = data.username === username;
            addMessage(data.message, isSentByMe, data.username, data.time);
        });

        socket.on('user-joined', (userData) => {
            if (!userData || !userData.username) return;
            
            if (userData.username !== username) {
                addSystemMessage(`${userData.username} joined the chat`);
            }
            updateUserList(userData.users);
        });

        socket.on('user-left', (userData) => {
            if (!userData || !userData.username) return;
            
            if (userData.username !== username) {
                addSystemMessage(`${userData.username} left the chat`);
            }
            updateUserList(userData.users);
        });

        socket.on('typing', (typingUsername) => {
            if (typingUsername && typingUsername !== username) {
                showTypingIndicator(typingUsername);
            }
        });

        socket.on('stopped-typing', () => {
            hideTypingIndicator();
        });

        socket.on('active-users', (users) => {
            updateUserList(users);
        });

        socket.on('error', (error) => {
            console.error('Socket error:', error);
            addSystemMessage('An error occurred: ' + error.message);
        });
    }

    // Set username and join chat
    function setUsername() {
        const name = usernameInput.value.trim();
        if (name) {
            username = name;
            usernameDisplay.textContent = name;
            
            // Generate a random color for the user avatar
            const colors = ['#4361ee', '#3f37c9', '#4cc9f0', '#4895ef', '#560bad'];
            const randomColor = colors[Math.floor(Math.random() * colors.length)];
            userAvatar.style.backgroundColor = randomColor;
            
            // Hide username input and show message input
            usernameContainer.style.display = 'none';
            messageInputContainer.style.display = 'flex';
            messageInput.disabled = false;
            sendButton.disabled = false;
            messageInput.focus();
            
            // Join the chat
            socket.emit('user-joined', username);
            
            // Add welcome message
            addSystemMessage(`Welcome to the chat, ${username}!`);
        }
    }

    // Send message to the server
    function sendMessage() {
        const message = messageInput.value.trim();
        if (message && username && isConnected) {
            const messageData = {
                message: message,
                time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
            };
            
            // Add message to UI immediately (optimistic update)
            addMessage(message, true, username, messageData.time);
            
            // Emit to server
            socket.emit('chat-message', messageData);
            
            // Clear input and reset typing state
            messageInput.value = '';
            resetTyping();
            
            // Scroll to bottom
            scrollToBottom();
        }
    }

    // Handle typing indicators
    function handleTyping() {
        if (!isTyping && username && isConnected) {
            isTyping = true;
            socket.emit('typing', username);
        }
        
        clearTimeout(typingTimeout);
        typingTimeout = setTimeout(resetTyping, 2000);
    }

    function resetTyping() {
        if (isTyping && username && isConnected) {
            isTyping = false;
            socket.emit('stopped-typing');
        }
    }

    function showTypingIndicator(typingUsername) {
        typingIndicator.textContent = `${typingUsername} is typing...`;
        typingIndicator.classList.add('active');
    }

    function hideTypingIndicator() {
        typingIndicator.classList.remove('active');
    }

    // Update connection status UI
    function updateConnectionStatus(connected) {
        if (connected) {
            connectionStatus.classList.remove('disconnected');
            connectionStatus.classList.add('connected');
            connectionText.textContent = 'Connected';
        } else {
            connectionStatus.classList.remove('connected');
            connectionStatus.classList.add('disconnected');
            connectionText.textContent = 'Disconnected';
        }
    }

    // Update active users list
    function updateUserList(users) {
        if (!Array.isArray(users)) return;
        
        activeUsers = users;
        userCount.textContent = users.length;
        
        // Update user list
        userList.innerHTML = '';
        users.forEach(user => {
            if (user !== username) { // Don't show ourselves in the list
                const li = document.createElement('li');
                li.textContent = user;
                userList.appendChild(li);
            }
        });
    }

    // Add message to chat UI
    function addMessage(message, isSent, senderName, time = '') {
        if (!message || !senderName) return;

        const messageGroup = document.createElement('div');
        messageGroup.className = `message-group ${isSent ? 'sent' : 'received'}`;

        // Add sender name for received messages
        if (!isSent) {
            const nameDiv = document.createElement('div');
            nameDiv.className = 'sender-name';
            nameDiv.textContent = senderName;
            messageGroup.appendChild(nameDiv);
        }

        // Add message content
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${isSent ? 'sent' : 'received'}`;
        messageDiv.textContent = message;
        
        // Add timestamp if available
        if (time) {
            const timeSpan = document.createElement('span');
            timeSpan.className = 'message-time';
            timeSpan.textContent = time;
            messageDiv.appendChild(timeSpan);
        }
        
        messageGroup.appendChild(messageDiv);

        // Add to chat and scroll
        chatMessages.appendChild(messageGroup);
        scrollToBottom();
    }

    // Add system message
    function addSystemMessage(message) {
        if (!message) return;

        const messageElement = document.createElement('div');
        messageElement.className = 'system-message';
        messageElement.textContent = message;
        chatMessages.appendChild(messageElement);
        scrollToBottom();
    }

    // Scroll to bottom of chat
    function scrollToBottom() {
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    // Initialize the application
    init();
});