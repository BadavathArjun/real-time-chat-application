const express = require('express');
const app = express();
const http = require('http').createServer(app);
const io = require('socket.io')(http, {
    cors: {
        origin: "*",
        methods: ["GET", "POST"],
        transports: ['websocket', 'polling'],
        credentials: true
    },
    allowEIO3: true
});

// Serve static files from public directory
app.use(express.static(__dirname + '/public'));

// Store active users
const activeUsers = new Map();

// Middleware to log connections
io.use((socket, next) => {
    console.log(`New connection attempt from ${socket.handshake.address}`);
    next();
});

// Socket.io connection handling
io.on('connection', (socket) => {
    console.log('A user connected:', socket.id);

    // Handle new user joining
    socket.on('user-joined', (username) => {
        if (!username || typeof username !== 'string') {
            socket.emit('error', { message: 'Invalid username' });
            return;
        }

        // Check if username is already taken
        if (Array.from(activeUsers.values()).includes(username)) {
            socket.emit('error', { message: 'Username is already taken' });
            return;
        }

        console.log('User joined:', username);
        socket.username = username;
        activeUsers.set(socket.id, username);

        // Broadcast to all clients that a new user joined
        const users = Array.from(activeUsers.values());
        io.emit('user-joined', {
            username: username,
            users: users
        });

        // Send current active users to the new user
        socket.emit('active-users', users);
    });

    // Handle chat messages
    socket.on('chat-message', (messageData) => {
        if (!socket.username) {
            return socket.emit('error', { message: 'You must join first' });
        }

        if (!messageData || !messageData.message || typeof messageData.message !== 'string') {
            return socket.emit('error', { message: 'Invalid message' });
        }

        console.log('Message received from:', socket.username, 'Content:', messageData.message);

        // Broadcast the message to all clients except sender
        const broadcastData = {
            username: socket.username,
            message: messageData.message,
            time: messageData.time || new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        };

        socket.broadcast.emit('chat-message', broadcastData);
    });

    // Handle user typing
    socket.on('typing', (username) => {
        if (username && socket.username === username) {
            socket.broadcast.emit('typing', username);
        }
    });

    // Handle user stopped typing
    socket.on('stopped-typing', () => {
        socket.broadcast.emit('stopped-typing');
    });

    // Handle disconnection
    socket.on('disconnect', () => {
        if (socket.username) {
            console.log('User disconnected:', socket.username);
            activeUsers.delete(socket.id);

            const users = Array.from(activeUsers.values());
            io.emit('user-left', {
                username: socket.username,
                users: users
            });
        }
    });

    // Handle errors
    socket.on('error', (error) => {
        console.error('Socket error:', error);
    });
});

// Error handling for the server
http.on('error', (error) => {
    console.error('Server error:', error);
});

const PORT = process.env.PORT || 3000;
http.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on port ${PORT}`);
    console.log(`Chat application is available at http://localhost:${PORT}`);
});

// Graceful shutdown
process.on('SIGINT', () => {
    console.log('Shutting down server...');
    io.close(() => {
        console.log('Socket.io server closed');
        process.exit(0);
    });
});